<section class="sejarah">
  <div class="container">
    <h2>Sejarah SMA Taman Madya IP Tamansiswa</h2>
    <p>
      SMA Taman Madya IP Tamansiswa berdiri pada tahun 1990 dengan tujuan memberikan pendidikan berkualitas di bidang ilmu pengetahuan dan teknologi. 
      Sejak didirikan, sekolah ini terus berkomitmen untuk meningkatkan mutu pendidikan dan mendukung pengembangan karakter siswa.
    </p>
    <p>
      Dengan dukungan tenaga pengajar yang kompeten dan fasilitas yang memadai, SMA Taman Madya IP Tamansiswa telah menghasilkan banyak lulusan yang sukses dan berkontribusi di berbagai bidang.
    </p>
    <p>
      Pada awal berdirinya, sekolah ini hanya memiliki beberapa program studi unggulan, namun seiring waktu telah berkembang dengan menambah berbagai program ekstra kurikuler dan fasilitas laboratorium yang modern. 
      Komitmen terhadap inovasi pendidikan membuat SMA Taman Madya IP Tamansiswa selalu beradaptasi dengan perkembangan ilmu pengetahuan dan teknologi terbaru.
    </p>
    <p>
      Selain fokus pada akademik, sekolah juga menanamkan nilai-nilai moral dan sosial kepada siswanya, sehingga menghasilkan lulusan yang tidak hanya cerdas secara intelektual, tapi juga berkarakter dan peduli terhadap lingkungan sekitar.
    </p>

    <!-- Gallery foto lama sekolah -->
    <div class="sejarah-images">
      <img src="images/foto-lama1.jpg" alt="Foto lama gedung sekolah" />
      <img src="images/foto-lama2.jpg" alt="Kegiatan siswa tahun 1995" />
      <img src="images/foto-lama3.jpg" alt="Foto guru dan staf lama" />
      <img src="images/foto-lama4.jpg" alt="Laboratorium komputer tahun 2000" />
    </div>
  </div>
</section>
