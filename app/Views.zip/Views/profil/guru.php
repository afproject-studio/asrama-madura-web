<?= $this->include('layouts/header') ?>

<h2>Data Guru SMA Taman Madya IP</h2>

<div class="list-guru">
    <?php 
    $count = 0;
    foreach($guru as $row): 
        if ($count % 2 == 0) echo '<div class="guru-row">'; // buka row setiap 2 item
    ?>
    <div class="guru-item">
        <div class="foto">
            <img src="<?= base_url('assets/foto/guru/' . $row['foto']) ?>" alt="Foto <?= esc($row['nama_lengkap']) ?>" />
        </div>
        <div class="info">
            <h3><?= esc($row['nama_lengkap']) ?></h3>
            <p><strong>Jabatan:</strong> <?= esc($row['jabatan']) ?></p>
            <p><strong>NUPTK:</strong> <?= esc($row['nuptk']) ?></p>
            <p><strong>Mapel:</strong> <?= esc($row['mapel']) ?></p>
        </div>
    </div>
    <?php 
        $count++;
        if ($count % 2 == 0) echo '</div>'; // tutup row setelah 2 item
    endforeach; 
    // jika ganjil, tutup div terakhir
    if ($count % 2 != 0) echo '</div>';
    ?>
</div>

<?= $this->include('layouts/footer') ?>
