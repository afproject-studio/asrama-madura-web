<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SMA Taman Madya IP Tamansiswa</title>

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- CSS Utama -->
  <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">

  <!-- Css Guru edit -->
   <link rel="stylesheet" href="<?= base_url('assets/css/guru.css') ?>">


  <!-- Font Awesome (untuk icon login, dll) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

  <!-- Header: Logo + Nama Sekolah -->
  <header class="header-top">
    <div class="container">
      <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo Sekolah" class="logo">
      <div class="school-name">
        <h1>SMA Taman Madya IP Tamansiswa</h1>
        <p>YOGYAKARTA</p>
      </div>
    </div>
  </header>

  <!-- Navbar -->
<!-- Navbar -->
<nav class="navbar">
  <div class="nav-container">
    <ul class="nav-list">
      <li><a href="<?= base_url('/') ?>">Beranda</a></li>
      <li class="dropdown">
        <a href="#">Profil</a>
        <ul class="dropdown-menu">
          <li><a href="<?= base_url('profil/sejarah') ?>">Sejarah</a></li>
          <li><a href="<?= base_url('profil/visi-misi') ?>">Visi & Misi</a></li>
          <li><a href="<?= base_url('profil/guru') ?>">Guru</a></li>
        </ul>
      </li>
      <li><a href="<?= base_url('kesiswaan') ?>">Kesiswaan</a></li>
      <li><a href="<?= base_url('berita') ?>">Berita</a></li>
      <li><a href="<?= base_url('galeri') ?>">Galeri</a></li>
      <li><a href="<?= base_url('kontak') ?>">Kontak</a></li>
    </ul>

    <!-- Kanan: Login atau Icon Admin -->
    <div class="nav-auth" id="navAuth">
      <?php if (session()->get('isLoggedIn')): ?>
        <a href="<?= base_url('/admin/dashboard') ?>" class="user-icon" title="Dashboard Admin">
          <i class="fas fa-user-circle"></i>
        </a>
      <?php else: ?>
        <a href="<?= base_url('admin') ?>" class="login-btn">
          <i class="fas fa-sign-in-alt"></i> Login
        </a>
      <?php endif; ?>
    </div>
  </div>
</nav>



  <!-- Konten Utama -->
  <main class="main-content">
