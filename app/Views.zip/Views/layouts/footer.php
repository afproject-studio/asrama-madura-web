  </main> <!-- Penutup main dari header.php -->

  <!-- Footer -->
  <footer class="footer">
    <div class="container-footer">
      <div class="footer-info">
        <h4>ALAMAT</h4>
        <p>Jl. Tamansiswa 25-d<br>Yogyakarta</p>
      </div>

      <div class="footer-info">
        <h4>KONTAK KAMI</h4>
        <div class="social-icons">
          <a href="https://facebook.com" target="_blank" aria-label="Facebook">
            <img src="<?= base_url('assets/img/fb.png') ?>" alt="Facebook">
          </a>
          <a href="https://instagram.com" target="_blank" aria-label="Instagram">
            <img src="<?= base_url('assets/img/ig.png') ?>" alt="Instagram">
          </a>
          <a href="https://wa.me/628123456789" target="_blank" aria-label="WhatsApp">
            <img src="<?= base_url('assets/img/wa.png') ?>" alt="WhatsApp">
          </a>
          <a href="mailto:info@tamanmadya.sch.id" aria-label="Email">
            <img src="<?= base_url('assets/img/email.png') ?>" alt="Email">
          </a>
        </div>
      </div>
    </div>

    <div class="copyright">
      <p>&copy; <?= date('Y') ?> | SMA Taman Madya IP Tamansiswa</p>
    </div>
  </footer>

</body>
</html>
