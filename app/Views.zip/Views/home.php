<?= $this->include('layouts/header') ?>

<!-- Hero Section -->
<section class="hero">
  <img src="<?= base_url('assets/img/hero.jpg') ?>" alt="Foto Sekolah">
  <div class="hero-text">
    <h2>Ing Ngarsa Sung Tuladha<br>Ing Madya Mangun Karsa<br>Tut Wuri Handayani</h2>
    <p>SMA Taman Madya IP Tamansiswa</p>
  </div>
</section>

<!-- Tentang Sekolah -->
<section class="tentang">
  <div class="container">
    <h3 style="text-align: center;">TENTANG SEKOLAH</h3>
    <div class="content">
      <img src="<?= base_url('assets/img/tentang.jpg') ?>" alt="Tentang Sekolah">
      <div class="text">
        <div class="garis"></div>
        <p>SMA Taman Madya IP Taman Siswa merupakan salah satu institusi pendidikan yang berlandaskan pada filosofi Ki Hadjar Dewantara, mengedepankan pendidikan yang membentuk karakter, kemandirian, dan kebangsaan. Sekolah ini berkomitmen untuk menciptakan lingkungan belajar yang aktif, kreatif, dan menyenangkan, serta mendorong peserta didik untuk berkembang secara akademik dan non-akademik. Dengan didukung oleh tenaga pendidik profesional dan berbagai fasilitas penunjang, SMA Taman Madya IP terus berupaya mencetak generasi penerus bangsa yang berakhlak mulia dan siap menghadapi tantangan zaman..</p>
      </div>
    </div>

    <!-- Tambahan Galeri Foto -->
    <div class="galeri-foto-tentang">
      <img src="<?= base_url('assets/img/tentang.JPG') ?>" alt="Foto Kegiatan 1">
      <div class="text">
        <div class="garis"></div>
        <p>Selain itu, SMA Taman Madya IP Taman Siswa juga aktif menyelenggarakan berbagai kegiatan ekstrakurikuler sebagai sarana pengembangan minat dan bakat siswa, mulai dari seni, olahraga, hingga keterampilan teknologi dan kewirausahaan. Kegiatan ini tidak hanya bertujuan untuk mencetak siswa yang berprestasi, tetapi juga menumbuhkan rasa percaya diri, kerja sama tim, dan semangat kepemimpinan.

Dalam proses pembelajarannya, sekolah ini mengintegrasikan pendekatan kontekstual yang relevan dengan kehidupan nyata, menjadikan peserta didik tidak hanya pintar secara intelektual, tetapi juga tangguh secara emosional dan sosial. Kurikulum yang diterapkan juga mendukung pendidikan karakter dan nilai-nilai kebangsaan, sejalan dengan semangat “Tut Wuri Handayani” yang diwariskan oleh Ki Hadjar Dewantara.

Dengan semangat gotong royong dan penguatan budaya sekolah yang positif, SMA Taman Madya IP Taman Siswa menjadi tempat tumbuh dan berkembangnya calon pemimpin masa depan yang cinta tanah air, mandiri, serta mampu beradaptasi di era global.</p>
      </div>
    </div>

  </div>
</section>

<!-- Visi Sekolah -->
<section class="visi">
  <h3>Visi Sekolah</h3>
  <p><em>Sekolah Berwawasan Kebangsaan, Unggul dalam IPTEK Berlandaskan Mutu Religius untuk Mewujudkan Manusia Berbudi Pekerti Luhur.</em></p>
</section>

<!-- Berita Terbaru -->
<section class="berita">
  <div class="container" style="text-align: center;">
    <h3>BERITA TERBARU</h3>
    <div class="berita-grid">
      <?php for ($i = 1; $i <= 3; $i++): ?>
        <div class="berita-item">
          <img src="<?= base_url('assets/img/berita'.$i.'.jpg') ?>" alt="Berita <?= $i ?>">
          <p class="tanggal">31 Juli 2025</p>
          <p class="preview">Lorem ipsum dolor sit amet, consectetuds am…...</p>
        </div>
      <?php endfor; ?>
    </div>
    <a href="<?= base_url('berita') ?>" class="btn-berita">Baca Selengkapnya</a>
  </div>
</section>

<!-- Quotes -->
<section class="quotes">
  <blockquote>
    <p>“Melalui ngerti, ngrasa, lan nglakoni (menyadari, menginsyafi, dan melakukan), budi pekerti yang dibentuk untuk merdeka dan mandiri akan hadir adab.”</p>
    <cite>Ki Hajar Dewantara</cite>
  </blockquote>
</section>

<?= $this->include('layouts/footer') ?>
