<?= $this->include('layouts/header') ?>

<div class="container-guru">
    <h2>Tambah Data Guru</h2>

    <?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <form action="<?= base_url('admin/guru/save') ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nama_lengkap">Nama Lengkap</label>
            <input type="text" name="nama_lengkap" id="nama_lengkap" required>
        </div>

        <div class="form-group">
            <label for="jabatan">Jabatan</label>
            <input type="text" name="jabatan" id="jabatan">
        </div>

        <div class="form-group">
            <label for="nuptk">NUPTK</label>
            <input type="text" name="nuptk" id="nuptk">
        </div>

        <div class="form-group">
            <label for="mapel">Mapel</label>
            <input type="text" name="mapel" id="mapel">
        </div>

        <div class="form-group">
            <label for="foto">Foto Guru (Max 6MB)</label>
            <input type="file" name="foto" id="foto" accept="image/*" required>
        </div>

        <button type="submit" class="btn-submit">Simpan</button>
    </form>
</div>

<?= $this->include('layouts/footer') ?>