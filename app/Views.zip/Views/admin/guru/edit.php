<?= $this->include('layouts/header') ?>

<div class="container-guru">
    <h2>Edit Data Guru</h2>

    <?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <form action="<?= base_url('admin/guru/update/' . $guru['id']) ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nama_lengkap">Nama Lengkap</label>
            <input type="text" name="nama_lengkap" id="nama_lengkap" value="<?= esc($guru['nama_lengkap']) ?>" required>
        </div>

        <div class="form-group">
            <label for="jabatan">Jabatan</label>
            <input type="text" name="jabatan" id="jabatan" value="<?= esc($guru['jabatan']) ?>">
        </div>

        <div class="form-group">
            <label for="nuptk">NUPTK</label>
            <input type="text" name="nuptk" id="nuptk" value="<?= esc($guru['nuptk']) ?>">
        </div>

        <div class="form-group">
            <label for="mapel">Mapel</label>
            <input type="text" name="mapel" id="mapel" value="<?= esc($guru['mapel']) ?>">
        </div>

        <div class="form-group">
            <label for="foto">Ganti Foto (Opsional)</label>
            <input type="file" name="foto" id="foto" accept="image/*">

            <?php if ($guru['foto']): ?>
            <div style="margin-top:10px;">
                <strong>Foto Saat Ini:</strong><br>
                <img src="<?= base_url('assets/foto/guru/' . $guru['foto']) ?>" width="100">
            </div>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn-submit">Update</button>
    </form>
</div>

<?= $this->include('layouts/footer') ?>