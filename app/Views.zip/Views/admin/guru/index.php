<?= $this->include('layouts/header') ?>

<div class="container-tabel">
    <h2>Data Guru</h2>

    <a href="<?= base_url('admin/guru/create') ?>" class="btn-dashboard mb-3">+ Tambah Guru</a>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Foto</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>NUPTK</th>
                <th>Mapel</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; foreach ($guru as $g): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td>
                        <?php if ($g['foto']): ?>
                            <img src="<?= base_url('assets/foto/guru/' . $g['foto']) ?>" width="60">
                        <?php else: ?>
                            <em>Tidak ada</em>
                        <?php endif ?>
                    </td>
                    <td><?= esc($g['nama_lengkap']) ?></td>
                    <td><?= esc($g['jabatan']) ?></td>
                    <td><?= esc($g['nuptk']) ?></td>
                    <td><?= esc($g['mapel']) ?></td>
                    <td>
                        <a href="<?= base_url('admin/guru/edit/' . $g['id']) ?>" class="btn-dashboard">Edit</a>
                        <a href="<?= base_url('admin/guru/delete/'.$g['id']) ?>" class="btn-dashboard" onclick="return confirm('Yakin hapus?')">Hapus</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<?= $this->include('layouts/footer') ?>
