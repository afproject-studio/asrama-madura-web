<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title><?= $title ?? 'Admin' ?></title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

    <div class="admin-layout">

        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>

        <!-- SIDEBAR -->
        <aside class="sidebar" id="adminSidebar">
            <h2 class="sidebar-title">Admin Panel</h2>
            <ul class="sidebar-menu">
                <li><a href="<?= base_url('admin/dashboard') ?>">Dashboard</a></li>
                <li><a href="<?= base_url('admin/guru') ?>">Data Guru</a></li>
                <li><a href="<?= base_url('admin/berita') ?>">Berita & Pengumuman</a></li>
                <li><a href="<?= base_url('admin/galeri') ?>">Galeri</a></li>
                <li><a href="<?= base_url('admin/kesiswaan') ?>">Kesiswaan</a></li>
                <li><a href="<?= base_url('admin/auth/logout') ?>"
                        onclick="return confirm('Yakin ingin logout?')">Logout</a></li>
            </ul>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="admin-content" id="adminContent">