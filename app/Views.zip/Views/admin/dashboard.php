<?= $this->include('layouts/header') ?>
<?= $this->include('admin/layout/sidebar') ?>

<div class="dashboard-wrapper">
    <h2 class="dashboard-title">Selamat Datang, <?= session()->get('admin_username') ?>!</h2>

    <div class="dashboard-grid">
        <div class="dashboard-card guru">
            <h3><?= $jumlahGuru ?></h3>
            <p>Guru</p>
            <a href="<?= base_url('admin/guru/create') ?>" class="btn-dashboard">+ Tambah</a>
        </div>

        <div class="dashboard-card berita">
            <h3><?= $jumlahBerita ?></h3>
            <p>Berita & Pengumuman</p>
            <small>Update: <?= date('d M Y', strtotime($lastBerita)) ?></small>
            <a href="<?= base_url('admin/berita/create') ?>" class="btn-dashboard">+ Tambah</a>
        </div>

        <div class="dashboard-card galeri">
            <h3><?= $jumlahGaleri ?></h3>
            <p>Galeri</p>
            <small>Update: <?= date('d M Y', strtotime($lastGaleri)) ?></small>
            <a href="<?= base_url('admin/galeri/create') ?>" class="btn-dashboard">+ Tambah</a>
        </div>

        <div class="dashboard-card kesiswaan">
            <h3><?= $jumlahKesiswaan ?></h3>
            <p>Kesiswaan</p>
            <small>Update: <?= date('d M Y', strtotime($lastKesiswaan)) ?></small>
            <a href="<?= base_url('admin/kesiswaan/create') ?>" class="btn-dashboard">+ Tambah</a>
        </div>
    </div>
</div>
</div>

<?= $this->include('admin/layout/sidebar_foot') ?>
<?= $this->include('layouts/footer') ?>